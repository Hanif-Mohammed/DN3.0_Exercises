import java.util.Arrays;

public class TestLibrarySearch {
    public static void main(String[] args) {
        Book[] books = {
            new Book("001", "Rich Dad Poor Dad", "Robert Kyosaki"),
            new Book("002", "1984", "George Orwell"),
            new Book("003", "After", "Anna Todd"),
            new Book("004", "A song of Ice and Fire", "George R R Martin"),
            new Book("005", "Harry Potter", "J K Rowling")
        };

        //Using Linear Search
        int index = LibrarySearch.linearSearch(books, "1984");
        System.out.println("Linear Search: Found '1984' at index " + index);

        // Sorting the array for binary search
        Arrays.sort(books, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));

        //Using Binary Search
        index = LibrarySearch.binarySearch(books, "1984");
        System.out.println("Binary Search: Found '1984' at index " + index);
    }
}

