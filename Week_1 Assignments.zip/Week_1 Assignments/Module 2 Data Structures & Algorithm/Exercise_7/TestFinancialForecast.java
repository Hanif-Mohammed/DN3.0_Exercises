public class TestFinancialForecast {
    public static void main(String[] args) {
        double currentValue = 1000.00;
        double growthRate = 0.05; // which is 5%
        int years = 10;
        double futureValue = FinancialForecast.predictFutureValue(currentValue, growthRate, years);
        System.out.println("Value after " + years + " years: " + futureValue);
    }
}
