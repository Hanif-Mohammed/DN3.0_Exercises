public class TestEmployeeManager {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();

        Employee e1 = new Employee("001", "Alice", "Manager", 80000);
        Employee e2 = new Employee("002", "Bob", "Developer", 60000);

        manager.addEmployee(e1);
        manager.addEmployee(e2);

        System.out.println("All employees:");
        manager.traverseEmployees();

        System.out.println("Search for employee with ID '002':");
        Employee employee = manager.searchEmployee("002");
        System.out.println(employee);

        manager.deleteEmployee("002");

        System.out.println("All employees after deletion:");
        manager.traverseEmployees();
    }
}

