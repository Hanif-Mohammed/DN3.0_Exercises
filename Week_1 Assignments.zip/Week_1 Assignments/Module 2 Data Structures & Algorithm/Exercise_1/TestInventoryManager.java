public class TestInventoryManager {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        Product p1 = new Product("001", "Laptop", 10, 999.99);
        Product p2 = new Product("002", "Smartphone", 20, 599.99);
        
        manager.addProduct(p1);
        manager.addProduct(p2);

        System.out.println("Inventory after adding products:");
        System.out.println(manager);

        p1.setPrice(899.99);
        manager.updateProduct(p1);

        System.out.println("Inventory after updating product:");
        System.out.println(manager);

        manager.deleteProduct("002");

        System.out.println("Inventory after deleting product:");
        System.out.println(manager);
    }
}

