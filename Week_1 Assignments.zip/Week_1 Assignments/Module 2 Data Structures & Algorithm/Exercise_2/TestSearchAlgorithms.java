import java.util.Arrays;

public class TestSearchAlgorithms {
    public static void main(String[] args) {
        Product[] products = {
            new Product("001", "Laptop", "Electronics"),
            new Product("002", "Smartphone", "Electronics"),
            new Product("003", "Tablet", "Electronics"),
            new Product("004", "Smartwatch", "Electronics"),
            new Product("005", "Headphones", "Electronics")
        };

        // LinearSearch
        int index = SearchAlgorithms.linearSearch(products, "Tablet");
        System.out.println("Linear Search: Found 'Tablet' at index " + index);

        // Sort the array for binary search
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareTo(p2.getProductName()));

        // BinarySearch
        index = SearchAlgorithms.binarySearch(products, "Tablet");
        System.out.println("Binary Search: Found 'Tablet' at index " + index);
    }
}
