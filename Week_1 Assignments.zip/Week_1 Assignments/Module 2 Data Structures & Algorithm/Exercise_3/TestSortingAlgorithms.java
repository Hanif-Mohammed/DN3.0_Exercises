import java.util.Arrays;

public class TestSortingAlgorithms {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("001", "Alice", 250.50),
            new Order("002", "Bob", 150.75),
            new Order("003", "Charlie", 300.20),
            new Order("004", "David", 100.10),
            new Order("005", "Eve", 200.00)
        };

        // Bubble Sorting the array
        BubbleSort.sort(orders);
        System.out.println("Orders sorted by Bubble Sort:");
        System.out.println(Arrays.toString(orders));

        // Resetting the array
        orders = new Order[]{
            new Order("001", "Alice", 250.50),
            new Order("002", "Bob", 150.75),
            new Order("003", "Charlie", 300.20),
            new Order("004", "David", 100.10),
            new Order("005", "Eve", 200.00)
        };

        // Quick Sorting the array
        QuickSort.sort(orders, 0, orders.length - 1);
        System.out.println("Orders sorted by Quick Sort:");
        System.out.println(Arrays.toString(orders));
    }
}

