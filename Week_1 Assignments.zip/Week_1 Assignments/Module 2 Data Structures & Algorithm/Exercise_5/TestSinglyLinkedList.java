public class TestSinglyLinkedList {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();

        Task t1 = new Task("001", "Task1", "Pending");
        Task t2 = new Task("002", "Task2", "Completed");

        list.addTask(t1);
        list.addTask(t2);

        System.out.println("All tasks:");
        list.traverseTasks();

        System.out.println("Search for task with ID '002':");
        Task task = list.searchTask("002");
        System.out.println(task);

        list.deleteTask("002");

        System.out.println("All tasks after deletion:");
        list.traverseTasks();
    }
}

