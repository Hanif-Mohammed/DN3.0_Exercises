public class Computer {
    private String CPU;
    private String RAM;
    private String ROM;
    private String GPU;

private Computer(Builder builder){
    this.CPU=builder.CPU;
    this.RAM=builder.RAM;
    this.ROM=builder.ROM;
    this.GPU=builder.GPU;
}
@Override
public String toString(){
    return "CPU: "+ CPU +" ,RAM: "+ RAM +" ,ROM: " + ROM +", GPU: " + GPU;
}
public static class Builder {
    private String CPU;
    private String RAM;
    private String ROM;
    private String GPU;

     public Builder setCPU(String CPU) {
            this.CPU = CPU;
            return this;
        }
        public Builder setRAM(String RAM) {
            this.RAM = RAM;
            return this;
        }
        public Builder setROM(String storage) {
            this.ROM = ROM;
            return this;
        }
        public Builder setGPU(String GPU) {
            this.GPU = GPU;
            return this;
        }
        public Computer build() {
            return new Computer(this);
        }
    }
}


