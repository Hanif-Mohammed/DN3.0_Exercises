public class Test {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        emailNotifier.send("Hello, Email!");

        System.out.println();

        Notifier smsEmailNotifier = new SmsNotifierDecorator(new EmailNotifier());
        smsEmailNotifier.send("Hello, Email and SMS!");

        System.out.println();

        Notifier slackSMSEmailNotifier = new SlackNotifierDecorator(new SmsNotifierDecorator(new EmailNotifier()));
        slackSMSEmailNotifier.send("Hello, Email, SMS, and Slack!");
    }
}