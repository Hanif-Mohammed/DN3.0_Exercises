public class Test {
    public static void main(String[] args) {
        PaytmGateway paytmGateway = new PaytmGateway();
        PaymentProcessor paytmProcessor = new PaytmAdapter(paytmGateway);
        paytmProcessor.processPayment(100.0);

        GpayGateway gpayGateway = new GpayGateway();
        PaymentProcessor gpayProcessor = new GpayAdapter(gpayGateway);
        gpayProcessor.processPayment(200.0);
    }
}
