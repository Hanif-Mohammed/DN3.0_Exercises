public class PaytmGateway {
    public void makePayment(double amount) {
        System.out.println("Amount through Paytm: " + amount);
    }
}
