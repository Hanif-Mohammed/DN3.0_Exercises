public class GpayGateway {
    public void makePayment(double amount) {
        System.out.println("Amount through Gpay: " + amount);
    }
}
