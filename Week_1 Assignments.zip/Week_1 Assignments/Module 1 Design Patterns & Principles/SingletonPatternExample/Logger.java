public class Logger {
    private static Logger singleton;
    private Logger(){
    }
    public static Logger getInstance(){
        if(singleton==null){
            singleton=new Logger();
        }
        return singleton;
    }
    public static void display(){
        System.out.println("called using the singleton object");
    }
}
