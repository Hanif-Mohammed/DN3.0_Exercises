public class Test {
    public static void main(String[] args) {
        Logger singleton1=Logger.getInstance();
        singleton1.display();
    }  
}
